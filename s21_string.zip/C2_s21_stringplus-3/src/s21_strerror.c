#include "s21_string.h"

char *s21_strerror(int errnum) {
  static char result[400] = {0};

#if defined(Darwin) || defined(__APPLE__)
  int max = 106;
  char *err[] = ERR_DARWIN
#else
  int max = 134;
  char *err[] = ERR_LINUX
#endif
      // изменить на s21_sprintf
      if (errnum < 0 || errnum > max) {
#if defined(Darwin) || defined(__APPLE__)
    sprintf(result, "Unknown error: %d", errnum);
#else
    sprintf(result, "Undefined error %d", errnum);
#endif
  }
  else s21_strncpy(result, err[errnum], 399);

  return result;
}