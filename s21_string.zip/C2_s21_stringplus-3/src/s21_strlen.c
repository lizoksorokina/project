#include "s21_string.h"

size_t s21_strlen(const char *str) { return (*str) ? s21_strlen(++str) + 1 : 0; }