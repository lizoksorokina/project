#include "s21_string.h"

s21_size_t s21_strspn(const char *str1, const char *str2) {
  s21_size_t len = 0;

  if (str1 && str2) {
    int match = 0, i = 0, end = 0;
    char *str1_copy = (char *)str1, *str2_copy = (char *)str2;

    for (; i <= (int)s21_strlen(str1_copy) && !end; i++) {
      match = 0;

      for (int j = 0; str2_copy[j] && !match; j++)
        if (str1_copy[i] == str2_copy[j]) match = 1;

      if (match == 0) {
        len = (s21_size_t)i;
        end = 1;
      }
    }
  }
  return len;
}