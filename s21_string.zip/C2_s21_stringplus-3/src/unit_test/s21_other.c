#include "s21_main_test.h"

START_TEST(test_strspn) {
  char s1[] = "123456789";
  char s2[] = "123";
  ck_assert_int_eq(strspn(s1, s2), s21_strspn(s1, s2));

  char s3[] = "456";
  ck_assert_int_eq(strspn(s1, s3), s21_strspn(s1, s3));

  char s4[] = "b";
  char s5[] = "barracuda";
  ck_assert_int_eq(strspn(s4, s5), s21_strspn(s4, s5));

  char s6[] = "";
  char s7[] = "Hello, world!";
  ck_assert_int_eq(strspn(s6, s7), s21_strspn(s6, s7));

  char s8[] = "Hello, world!";
  char s9[] = "";
  ck_assert_int_eq(strspn(s8, s9), s21_strspn(s8, s9));

  char s10[] = "6";
  char s11[] = "67";
  ck_assert_int_eq(strspn(s10, s11), s21_strspn(s10, s11));

  char s12[] = "69917020";
  char s13[] = "69917020";
  ck_assert_int_eq(strspn(s12, s13), s21_strspn(s12, s13));

  char s14[] = "699";
  char s15[] = "69917020";
  ck_assert_int_eq(strspn(s14, s15), s21_strspn(s14, s15));

  char s16[] = "69917020";
  char s17[] = "699";
  ck_assert_int_eq(strspn(s16, s17), s21_strspn(s16, s17));

  char s18[] = "";
  char s19[] = "";
  ck_assert_int_eq(strspn(s18, s19), s21_strspn(s18, s19));

  char s20[] = "69917020";
  char s21[] = "6991702H";
  ck_assert_int_eq(strspn(s20, s21), s21_strspn(s20, s21));
}
END_TEST

Suite *other_functions(void) {
  Suite *other;
  TCase *tc_core;

  other = suite_create("other functions test");
  tc_core = tcase_create("Other");

  tcase_add_test(tc_core, test_strspn);
  suite_add_tcase(other, tc_core);

  return other;
}
