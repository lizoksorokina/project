#include "s21_main_test.h"

int main(void) {
  int number_failed;
  SRunner *run_lib;

  run_lib = srunner_create(mem_functions());
  srunner_add_suite(run_lib, str_functions());
  srunner_add_suite(run_lib, sharp_functions());
  srunner_add_suite(run_lib, other_functions());
  srunner_run_all(run_lib, CK_NORMAL);

  number_failed = srunner_ntests_failed(run_lib);
  srunner_free(run_lib);

  // сюда добавить тест. наборы для sprintf & sscanf

  return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
