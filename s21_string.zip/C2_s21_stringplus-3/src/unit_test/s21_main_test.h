#ifndef TEST_H
#define TEST_H

#include <check.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../source/s21_string.h"

Suite *mem_functions(void);
Suite *str_functions(void);
Suite *sharp_functions(void);
Suite *other_functions(void);
Suite *string_lib(void);

#endif