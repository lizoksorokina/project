#include "s21_main_test.h"

// mem tests

START_TEST(test_memchr) {
  char str[] = "69917020";
  int ch = '\0';
  s21_size_t len = 9;
  ck_assert_ptr_eq(memchr(str, ch, len), s21_memchr(str, ch, len));

  unsigned char src[15] = "134567234567890";
  int *sym = memchr(src, '4', 10);
  int *res = s21_memchr(src, '4', 10);

  ck_assert_ptr_eq(sym, res);

  char *str_1 = "Hello";
  size_t n = strlen(str);
  char c = 'b';
  ck_assert_ptr_eq((char *)memchr(str_1, c, n),
                   (char *)s21_memchr(str_1, c, n));
}
END_TEST

START_TEST(test_memcmp) {
  char *str[] = {"a", "abc", "", "abc", "abs", "a", "abc", ""};
  for (int i = 0; i < 7; i++) {
    ck_assert_int_eq(memcmp(str[i], str[i + 1], 10),
                     s21_memcmp(str[i], str[i + 1], 10));
  }
}
END_TEST

START_TEST(test_memcpy) {
  char *src[] = {"a", "abc", "", "abc", "abs", "a", "abc", ""};
  char dest_my[10] = {0};
  char dest_ori[10] = {0};
  for (int i = 0; i < 8; i++) {
    memcpy(dest_ori, src[i], 3);
    s21_memcpy(dest_my, src[i], 3);

    ck_assert_str_eq(dest_ori, dest_my);
  }
}
END_TEST

START_TEST(test_memset) {
  char src[] = {"privetik verter davai kto silnee"};
  char src_1[] = {"privetik verter davai kto silnee"};

  memset(src, '1', 5);
  s21_memset(src_1, '1', 5);

  ck_assert_str_eq(src, src_1);
}
END_TEST

Suite *mem_functions(void) {
  Suite *memtest;
  TCase *tc_core;

  memtest = suite_create("mem function test");

  tc_core = tcase_create("Mem");

  tcase_add_test(tc_core, test_memchr);
  tcase_add_test(tc_core, test_memcmp);
  tcase_add_test(tc_core, test_memcpy);
  tcase_add_test(tc_core, test_memset);

  suite_add_tcase(memtest, tc_core);

  return memtest;
}
