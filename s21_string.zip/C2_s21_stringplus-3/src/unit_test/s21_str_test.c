#include "s21_main_test.h"

// str tests

START_TEST(test_strlen) {
  char *source = {
      "QWERTYUIOPASDFGHJKLZXCVBNM\n[]'\\./"
      ",1234567890-=!@#$%%^&*()_`~№<>;:\nйцукенгшщзхъфывапролджэёячсмитьбю"};

  ck_assert_int_eq(s21_strlen(source), strlen(source));
}
END_TEST

START_TEST(test_strncat) {
  char str[20] = {"abra"};
  char str_1[20] = {"abra"};
  char str_2[20] = {" cadabra"};
  strncat(str, str_2, 8);
  s21_strncat(str_1, str_2, 8);

  ck_assert_str_eq(str, str_1);
}
END_TEST

START_TEST(test_strchr) {
  char str[] = {"abra cadabra"};
  char *ori = strchr(str, 'c');
  char *my = s21_strchr(str, 'c');

  ck_assert_ptr_eq(ori, my);

  char str_1[] = "134567234567890";
  char *ori_1 = strchr(str_1, '4');
  char *my_1 = s21_strchr(str_1, '4');

  ck_assert_ptr_eq(ori_1, my_1);

  ck_assert_ptr_eq(strchr(str, '\0'), s21_strchr(str, '\0'));

  ck_assert_ptr_eq(strchr(str, 'l'), s21_strchr(str, 'l'));
}
END_TEST

START_TEST(test_strncmp) {
  char *str[] = {"a", "abc", "", "abc", "abs", "a", "abc", ""};
  for (int i = 0; i < 7; i++) {
    ck_assert_int_eq(strncmp(str[i], str[i + 1], 10),
                     s21_strncmp(str[i], str[i + 1], 10));
  }

  char str1[] = {"asdfg"};
  char str2[] = {"asdfgg"};
  char str3[] = {"as"};
  ck_assert_int_eq(strncmp(str1, str1, 10), s21_strncmp(str1, str1, 10));

  ck_assert_int_eq(strncmp(str1, str2, 10), s21_strncmp(str1, str2, 10));

  ck_assert_int_eq(strncmp(str1, str3, 10), s21_strncmp(str1, str3, 10));
}
END_TEST

START_TEST(test_strncpy) {
  char str[20] = {"abra"};
  char str_1[20] = {"abra"};
  char str_2[20] = {" cadabra"};
  char str_3[20] = {" lol"};
  strncpy(str, str_2, 8);
  s21_strncpy(str_1, str_2, 8);
  ck_assert_str_eq(str, str_1);

  strncpy(str, str_3, 8);
  s21_strncpy(str_1, str_3, 8);
  ck_assert_str_eq(str, str_1);

  char dest[10];
  char s21_dest[10];
  char *src = "hello";

  ck_assert_str_eq(strncpy(dest, src, 10), s21_strncpy(s21_dest, src, 10));
}
END_TEST

START_TEST(test_strcspn) {
  char str1[] = {"abcde312$#@"};
  char str2[] = {"*$#"};
  char str3[] = {" cadabra lol"};
  char str4[] = {" lol"};

  ck_assert_int_eq(strcspn(str1, str2), s21_strcspn(str1, str2));
  ck_assert_int_eq(strcspn(str3, str4), s21_strcspn(str3, str4));
  ck_assert_int_eq(strcspn(str1, str4), s21_strcspn(str1, str4));
}
END_TEST

START_TEST(test_strerror) {
  for (int i = -2; i < 134; i++) ck_assert_str_eq(strerror(i), s21_strerror(i));
}
END_TEST

START_TEST(test_strpbrk) {
  char str1[] = {"abcde312$#@"};
  char str2[] = {"*$#"};
  char str3[] = {" cadabra lol"};
  char str4[] = {" lol"};

  ck_assert_str_eq(strpbrk(str1, str2), s21_strpbrk(str1, str2));
  ck_assert_str_eq(strpbrk(str3, str4), s21_strpbrk(str3, str4));
  ck_assert_ptr_eq(strpbrk(str1, str4), s21_strpbrk(str1, str4));
}
END_TEST

START_TEST(test_strrchr) {
  char str1[] = {"abcde312$#@"};
  char c = 'a', c1 = '@', c2 = '3', c3 = 'l';

  ck_assert_str_eq(strrchr(str1, c), s21_strrchr(str1, c));
  ck_assert_str_eq(strrchr(str1, c1), s21_strrchr(str1, c1));
  ck_assert_str_eq(strrchr(str1, c2), s21_strrchr(str1, c2));
  ck_assert_ptr_eq(strrchr(str1, c3), s21_strrchr(str1, c3));
}
END_TEST

START_TEST(test_strstr) {
  char *str = "Try not. Do, or do not. There is no try.";
  char *target = "not";
  char *target1 = "not ";
  char *target2 = "";

  char *result = str;
  char *result1 = str;
  char *result2 = str;
  char *result3 = str;
  char *result4 = str;
  char *result5 = str;

  ck_assert_str_eq(strstr(result, target), s21_strstr(result1, target));
  ck_assert_ptr_eq(strstr(result2, target1), s21_strstr(result3, target1));
  ck_assert_str_eq(strstr(result4, target2), s21_strstr(result5, target2));
  ck_assert_ptr_eq(strstr(target2, target1), s21_strstr(target2, target1));

  const char *haystack = "Testing strstr, heh";
  const char *needle = "str";
  char *result_original = strstr(haystack, needle);
  char *result_custom = s21_strstr(haystack, needle);
  ck_assert_str_eq(result_original, result_custom);

  const char *haystack_1 = "This is another example for testing";
  const char *needle_1 = "another";

  char *result_original_1 = strstr(haystack_1, needle_1);
  char *result_custom_1 = s21_strstr(haystack_1, needle_1);
  ck_assert_str_eq(result_original_1, result_custom_1);

  char s1[] = "aaaaasususususpicioussusususpicious";
  char s2[] = "susp";
  ck_assert_str_eq(strstr(s1, s2), s21_strstr(s1, s2));
}
END_TEST

START_TEST(test_strtok) {
  char s1[] = ",one,two,three";
  char s2[] = ",one,two,three";
  char s3[] = ",";
  ck_assert_pstr_eq(strtok(s1, s3), s21_strtok(s2, s3));

  for (int i = 1; i <= 5; i++)
    ck_assert_pstr_eq(strtok(NULL, s2), s21_strtok(NULL, s2));

  char input[] = "one + two * (three - four)!";
  const char *delimiters = "! +- (*)";

  char *token = s21_strtok(input, delimiters);
  char *token_ori = strtok(input, delimiters);
  ck_assert_str_eq(token, token_ori);
  char *tok = &token[4];
  char *tok_ori = &token_ori[4];
  ck_assert_str_eq(tok, tok_ori);

  token = s21_strtok(token, delimiters);
  token_ori = strtok(token, delimiters);
  ck_assert_str_eq(token, token_ori);
  tok = &token[4];
  tok_ori = &token_ori[4];
  ck_assert_str_eq(tok, tok_ori);

  char end[] = "+ two * ";
  char end_ori[] = "+ two * ";
  char *token_U = s21_strtok(end, delimiters);
  char *token_ori_U = strtok(end_ori, delimiters);
  ck_assert_str_eq(token_U, token_ori_U);
  tok = &token[4];
  tok_ori = &token_ori[4];
  ck_assert_str_eq(tok, tok_ori);

  char input1[] = "";
  char *token1 = s21_strtok(input1, delimiters);
  char *token_ori1 = strtok(input1, delimiters);
  ck_assert_ptr_eq(token1, token_ori1);

  const char *delimiters2 = "";
  char *token2 = s21_strtok(input1, delimiters2);
  char *token_ori2 = strtok(input1, delimiters2);
  ck_assert_ptr_eq(token2, token_ori2);

  char *token3 = s21_strtok(input, delimiters2);
  char *token_ori3 = strtok(input, delimiters2);
  ck_assert_str_eq(token3, token_ori3);

  char s4[] = "Hello, world!";
  char s5[] = "Hello, world!";
  char s6[] = "Hello, world!";
  ck_assert_pstr_eq(strtok(s4, s6), s21_strtok(s5, s6));
}
END_TEST

Suite *str_functions(void) {
  Suite *str;
  TCase *tc_core;

  str = suite_create("str functions test");

  tc_core = tcase_create("Str");

  tcase_add_test(tc_core, test_strlen);
  tcase_add_test(tc_core, test_strncat);
  tcase_add_test(tc_core, test_strchr);
  tcase_add_test(tc_core, test_strncmp);
  tcase_add_test(tc_core, test_strncpy);
  tcase_add_test(tc_core, test_strcspn);
  tcase_add_test(tc_core, test_strerror);
  tcase_add_test(tc_core, test_strpbrk);
  tcase_add_test(tc_core, test_strrchr);
  tcase_add_test(tc_core, test_strstr);
  tcase_add_test(tc_core, test_strtok);

  suite_add_tcase(str, tc_core);

  return str;
}