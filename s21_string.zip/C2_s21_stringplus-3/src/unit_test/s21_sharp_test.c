#include "s21_main_test.h"

// bonus functions tests

START_TEST(test_to_upper) {
  char *source = {
      "qwertyuiopasdfghjklzxcvbnm\n[]'\\./"
      ",1234567890-=!@#$%%^&*()_`~№<>;:\nйцукенгшщзхъфывапролджэёячсмитьбю"};
  char *result_1 = NULL;
  result_1 = s21_to_upper(source);

  ck_assert_str_eq(
      result_1,
      "QWERTYUIOPASDFGHJKLZXCVBNM\n[]'\\./"
      ",1234567890-=!@#$%%^&*()_`~№<>;:\nйцукенгшщзхъфывапролджэёячсмитьбю");

  free(result_1);
}
END_TEST

START_TEST(test_to_lower) {
  char *source = {
      "QWERTYUIOPASDFGHJKLZXCVBNM\n[]'\\./"
      ",1234567890-=!@#$%%^&*()_`~№<>;:\nйцукенгшщзхъфывапролджэёячсмитьбю"};
  char *result_1 = NULL;
  result_1 = s21_to_lower(source);

  ck_assert_str_eq(
      result_1,
      "qwertyuiopasdfghjklzxcvbnm\n[]'\\./"
      ",1234567890-=!@#$%%^&*()_`~№<>;:\nйцукенгшщзхъфывапролджэёячсмитьбю");

  free(result_1);
}
END_TEST

START_TEST(test_to_insert) {
  char *biba = {"biba"};
  char *boba = {" boba "};
  char *result_1 = NULL;
  result_1 = s21_insert(biba, boba, 2);

  ck_assert_str_eq(result_1, "bi boba ba");

  // если вылет за пределы массива result_1 = 0 (null == null doesn't work)
  // (а тест фэйлится, если значение false, так что стоит отрицание "!()")
  result_1 = s21_insert(biba, boba, 6);
  ck_assert(!(result_1));

  free(result_1);
}
END_TEST

START_TEST(test_to_trim) {
  char *src = {"^(^OOO_^The OOOjOu^^"};
  char trim_chars[] = {'(', ')', '^', 'O'};
  char *result = S21_NULL;
  result = s21_trim(src, trim_chars);

  ck_assert_str_eq(result, "_^The OOOjOu");

  char *src_2 = {"    ^(^OOO_^The OOOjOu^^"};
  char *trim_chars_2 = S21_NULL;
  char *result_2 = S21_NULL;
  result_2 = s21_trim(src_2, trim_chars_2);

  ck_assert_ptr_eq(result_2, NULL);

  char *src_3 = {"    ^(^OOO_^The OOOjOu^^"};
  char trim_chars_3[] = {'\0'};
  char *result_3 = S21_NULL;
  result_3 = s21_trim(src_3, trim_chars_3);

  // т.к. я отключила реализацию удаления " " и "\n"
  // ck_assert_str_eq(result_3, "^(^OOO_^The OOOjOu^^");
  ck_assert_str_eq(result_3, "    ^(^OOO_^The OOOjOu^^");

  char *src_4 = {".    OIIIyhddgsj    \t."};
  char trim_chars_4[] = {' '};
  char *result_4 = S21_NULL;
  result_4 = s21_trim(src_4, trim_chars_4);

  ck_assert_str_eq(result_4, ".    OIIIyhddgsj    \t.");

  free(result);
  free(result_2);
  free(result_3);
  free(result_4);
}
END_TEST

Suite *sharp_functions(void) {
  Suite *sharp;
  TCase *tc_core;

  sharp = suite_create("bonus functions test");

  tc_core = tcase_create("Sharp");

  tcase_add_test(tc_core, test_to_upper);
  tcase_add_test(tc_core, test_to_lower);
  tcase_add_test(tc_core, test_to_insert);
  tcase_add_test(tc_core, test_to_trim);

  suite_add_tcase(sharp, tc_core);

  return sharp;
}