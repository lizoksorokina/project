
#include "s21_string.h"
//typedef int Spec;


int s21_sprintf(char *str, const char *format, ...) {
  char specifiers[] =
      "diuoxXcsnpfFeEgG%";  // изначальное положение str записыаем в src,
  // чтобы узнать сколько символов мы записали

  char *src = str;  // начальное количесвто символов

  va_list arguments;  // передаем указатель
  va_start(arguments, format);  // переменная, которая идет перед ...

  while (*format) {
    if (*format == '%') {
      format++;
      Spec specs = {0};
      specs.number_system = 10;
      format = set_specs(&specs, format, &arguments);
      while (!s21_strchr(specifiers, *format)) format++;
      str = parser(str, src, format, specs, &arguments);
    } else {
      *str = *format;
      str++;
    }
    format++;
  }
  *str = '\0';
  va_end(arguments);
  return (str - src);
}

const char *set_specs(Spec *specs, const char *format, va_list *arguments) {
  format = get_specs(format, specs);  // обрабатываем флаги
  format = get_width(format, &specs->width, arguments);  // обрабатыввем ширину
  if (*format == '.') {  // если осталась точка - это указывает на ширину
    specs->dot = 1;
    specs->zero = 0;  // не можеь быть и точность и ноль
    format += 1;
    format = get_width(format, &specs->accuracy, arguments);
  }
  if (*format == '.') {
    specs->dot = 1;
    specs->zero = 0;
    format += 1;
    format = get_width(format, &specs->accuracy, arguments);
  }
  if (*format == 'L')
    specs->length = 'L';
  else if (*format == 'l')
    specs->length = 'l';
  else if (*format == 'h')
    specs->length = 'h';
  if (specs->length != 0) format += 1;

  if (specs->width < 0) {
    specs->width = -specs->width;
    specs->minus = 1;
  }
  return format;
}

const char *get_specs(const char *format, Spec *specs) {
  while (format) {
    if (*format == '+')
      specs->plus = 1;
    else if (*format == '-')
      specs->minus = 1;
    else if (*format == '#')
      specs->hash = 1;
    else if (*format == ' ')
      specs->space = 1;
    else if (*format == '0')
      specs->zero = 1;
    else
      break;
    format++;
  }
  specs->space = (specs->space &&
                  !specs->plus);  // не может быть одновременно и плюс и пробел
  specs->zero =
      (specs->zero && !specs->minus);  // не может быть одновременно и минус и
                                       // ноль - ноль уничтожаеться
  return format;
}

const char *get_width(const char *format, int *width, va_list *arguments) {
  *width = 0;
  if (*format == '*') {
    *width = va_arg(*arguments, int);
    format++;
  }
  while (format) {
    if ('0' <= *format && *format <= '9') {
      *width *= 10;
      *width += *format - '0';
    } else
      break;
    format++;
  }
  return format;
}

Spec set_number_system(Spec specs, char format) {
  if (format == 'o')  // если о то восьмиричная система
    specs.number_system = 8;
  else if (format == 'x' || format == 'X')  //  если х то шестнадцатеричная
    specs.number_system = 16;
  if (format == 'X') specs.upper_case = 1;
  return specs;
}

char *parser(char *str, char *src, const char *format, Spec specs,
             va_list *arguments) {
  if (*format == 'd' || *format == 'i') {
    str = print_decimal(str, specs, arguments);
  } else if (*format == 'u' || *format == 'o' || *format == 'x' ||
             *format == 'X') {
    specs = set_number_system(specs, *format);
    str = print_u(str, specs, *(format - 1), arguments);
  } else if (*format == 'c') {
    int symbol = va_arg(*arguments, int);
    str = print_c(str, specs, symbol);
  } else if (*format == 's') {
    str = print_c(str, specs, *arguments);
  } else if (*format == 's') {
    str = print_c(str, specs, *arguments);
  } else if (*format == 'n') {
    int *n = va_arg(*arguments, int *);
    *n = (int)(str - src);
  } else if (*format == 'f' || *format == 'F') {
    specs = set_spec_for_double(specs, *format);
    str = print_double(str, specs, *(format -1), arguments);
  } else if (*format == 'E' || *format == 'e' || *format == 'g' ||
             *format == 'G') {
  } else if (*format == '%') {
    str = print_c(str, specs, '%');  // просто передаем символ
  }
}

char *print_decimal(char *str, Spec specs, va_list *arguments) {
  long int num = 0;
  if (specs.length == 'l') {
    num = (long int)va_arg(*arguments, long int);
  } else if (specs.length == 'h') {
    num = (short)va_arg(*arguments, int);
  } else {
    num = (int)va_arg(*arguments, int);
  }
  // функция подсчета для буферного массива
  s21_size_t size_to_decimal = get_size_to_decimal(&specs, num);   
  char *str_to_num = malloc(sizeof(char) * size_to_decimal);
  if (str_to_num) {  // проверка на выделение памяти
    int i = decimal_to_string(specs, num, str_to_num, size_to_decimal);
    for (int j = i - 1; j >= 0; j--) {  // записывает переменную в буферный
                                        // массив
      *str = str_to_num[j];  // запишеться в обратном порядке
      str++;
    }
    while ((i < specs.width)) {
      *str = ' ';
      str++;
    }
  }
  if (str_to_num) free(str_to_num);
  return str;
}

s21_size_t size_to_decimal(Spec *specs, long int num) {
  s21_size_t result = 0;
  long int copy_num = num;
  if (copy_num < 0) copy_num = -copy_num;
  while (copy_num > 0) {
    copy_num /= 10;
    result++;
  }
  if (copy_num == 0 && result == 0 &&
      (specs->accuracy || specs->width || specs->space)) {
    result++;
  }
  if ((s21_size_t)specs->width > result) result = specs->width;
  if ((s21_size_t)specs->accuracy > result) result = specs->accuracy;
  if (specs->space || specs->plus || num < 0) {
    specs->flag_to_size = 1;
    result++;
  }
  if (result == 0 && copy_num == 0 && !specs->accuracy && !specs->width &&
      !specs->space && !specs->dot)
    result++;
  return result;
}

int decimal_to_string(Spec specs, long int num, char *str_to_num,
                      s21_size_t size_to_decimal) {
  int flag = 0;  // положит или отриц число

  if (num < 0) {
    flag = 1;
    num = -num;
  }

  int i = 0;
  long int copy_num = num;

  // запись числа в буферный массив
  // если число == 0
  if ((copy_num == 0 && (specs.accuracy || specs.width || specs.space)) ||
      (copy_num == 0 && !specs.accuracy && !specs.width && !specs.space &&
       !specs.dot)) {
    char sym = copy_num % specs.number_system + '0';
    str_to_num[i] = sym;
    i++;
    size_to_decimal--;
    copy_num /= 10;
  }
  // запись числа в буферный массив
  // если число != 0
  while (copy_num != 0 && str_to_num && size_to_decimal) {
    char sym = get_num_char(copy_num % specs.number_system, specs.upper_case);
    str_to_num[i] = sym;
    i++;
    size_to_decimal--;
    copy_num /= 10;
  }
  if (flag) num = -num;
  // проверка на то можем ли мы применить флаг 0
  if (specs.accuracy - i > 0) {  // если точность больше чем ширина применяем
                                 // флаг
    specs.accuracy -= i;
    specs.zero = 1;
  } else
    flag = 1;
  // если у нас не осталось места под нули
  if (size_to_decimal == 1 && specs.zero == 1 && specs.flag_to_size == 1)
    specs.zero = 0;

  // обработка флага 0
  while (specs.zero && str_to_num &&
         (size_to_decimal - specs.flag_to_size > 0) &&
         (specs.accuracy || flag)) {
    if ((size_to_decimal == 1 && specs.flag_to_size == 1)) break;
    str_to_num[i] = '0';
    i++;
    size_to_decimal--;
    specs.accuracy--;
  }
  // обработка флагов + - пробел
  if (specs.space && num >= 0 && size_to_decimal) {
    str_to_num[i] = ' ';
    i++;
    size_to_decimal--;
  }
  if (num < 0 && size_to_decimal) {
    str_to_num[i] = '-';
    i++;
    size_to_decimal--;
  }
  if (num > 0 && specs.plus && size_to_decimal) {
    str_to_num[i] = '+';
    i++;
    size_to_decimal--;
  }
  // обработка ситуации, когда осталось свободное место в строке
  if (size_to_decimal > 0 && specs.minus == 0) {
    while ((size_to_decimal - specs.flag_to_size > 0) && str_to_num) {
      str_to_num[i] = ' ';
      i++;
      size_to_decimal;
    }
  }
  return i;
}

char *print_u(char *str, Spec specs, char format, va_list *arguments) {
  // обработка u x X o
  unsigned long int num = 0;
  if (format == 'l')
    num = (unsigned long int)va_arg(*arguments, unsigned long int);
  else if (format == 'h')
    num = (unsigned short)va_arg(*arguments, unsigned int);
  else
    num = (unsigned int)va_arg(*arguments, unsigned int);

  // функция для вычесления размера массива
  s21_size_t size_to_num = get_buf_size_unsigned_decimal(
      specs, num);  // я ее писала сама - самая последняя
  char *buffer = malloc(sizeof(char) * size_to_num);
  if (buffer) {
    int i = unsigned_decimal_to_string(buffer, specs, num, size_to_num);
    for (int j = i - 1; j >= 0; j--) {  // записывает переменную в буферный
                                        // массив
      *str = buffer[j];  // запишеться в обратном порядке
      str++;
    }
    while ((i < specs.width)) {
      *str = ' ';
      str++;
    }
  }
  if (buffer) free(buffer);
  return str;
}

/*int unsigned_decimal_to_string(char *buffer, Spec specs, unsigned long int num,
                               s21_size_t size_to_num) {
  int i = 0;
  int flag = 0;
  unsigned long int copy_num = num;

  if (specs.hash && specs.number_system == 8)
    specs.flag_to_size = 1;
  else if (specs.hash && specs.number_system == 16) {
    specs.flag_to_size = 2;
  }

  while (copy_num != 0 && buffer && size_to_decimal) {
    char sym = get_num_char(copy_num % specs.number_system, specs.upper_case);
    buffer[i] = sym;
    i++;
    size_to_num--;
    copy_num /= 10;
  }
  if (flag) num = -num;
  // проверка на то можем ли мы применить флаг 0
  if (specs.accuracy - i > 0) {  // если точность больше чем ширина применяем
                                 // флаг
    specs.accuracy -= i;
    specs.zero = 1;
  } else
    flag = 1;
  // если у нас не осталось места под нули
  if (size_to_decimal == 1 && specs.zero == 1 && specs.flag_to_size == 1)
    specs.zero = 0;

  // обработка флага 0
  while (specs.zero && buffer && (size_to_decimal - specs.flag_to_size > 0) &&
         (specs.accuracy || flag)) {
    if ((size_to_decimal == 1 && specs.flag_to_size == 1)) break;
    buffer[i] = '0';
    i++;
    size_to_num--;
    specs.accuracy--;
  }
  // обработка флагов + - пробел
  if (specs.hash && specs.number_system == 8) {
    buffer[i] = '0';
    i++;
    size_to_num--;
  } else if (specs.hash && specs.number_system == 16 && specs.upper_case) {
    buffer[i] = 'X';
    i++;
    size_to_num--;
    buffer[i] = '0';
    i++;
    size_to_num--;
  } else if (specs.hash && specs.number_system == 16 && !specs.upper_case) {
    buffer[i] = 'x';
    i++;
    size_to_num--;
    buffer[i] = '0';
    i++;
    size_to_num--;
  }

  // обработка ситуации, когда осталось свободное место в строке
  if (size_to_decimal > 0 && specs.minus == 0) {
    while ((size_to_decimal - specs.flag_to_size > 0) && buffer) {
      buffer[i] = ' ';
      i++;
      size_to_decimal;
    }
  }
  return i;
}*/

int unsigned_decimal_to_string(char *buffer, Spec specs, unsigned long int num,
                               s21_size_t size_to_num) {
  int i = 0;
  int flag = 0;
  unsigned long int copy_num = num;

  if (specs.hash && specs.number_system == 8)
    specs.flag_to_size = 1;
  else if (specs.hash && specs.number_system == 16) {
    specs.flag_to_size = 2;
  }

  while (copy_num != 0 && buffer && size_to_num) {
    char sym = get_num_char(copy_num % specs.number_system, specs.upper_case);
    buffer[i] = sym;
    i++;
    size_to_num--;
    copy_num /= 10;
  }
  if (flag) num = -num;
  // проверка на то можем ли мы применить флаг 0
  if (specs.accuracy - i > 0) {  // если точность больше чем ширина применяем
                                 // флаг
    specs.accuracy -= i;
    specs.zero = 1;
  } else
    flag = 1;
  // если у нас не осталось места под нули
  if (size_to_num == 1 && specs.zero == 1 && specs.flag_to_size == 1)
    specs.zero = 0;

  // обработка флага 0
  while (specs.zero && buffer && (size_to_num - specs.flag_to_size > 0) &&
         (specs.accuracy || flag)) {
    if ((size_to_num == 1 && specs.flag_to_size == 1)) break;
    buffer[i] = '0';
    i++;
    size_to_num--;
    specs.accuracy--;
  }
  // обработка флагов + - пробел
  if (specs.hash && specs.number_system == 8) {
    buffer[i] = '0';
    i++;
    size_to_num--;
  } else if (specs.hash && specs.number_system == 16 && specs.upper_case) {
    buffer[i] = 'X';
    i++;
    size_to_num--;
    buffer[i] = '0';
    i++;
    size_to_num--;
  } else if (specs.hash && specs.number_system == 16 && !specs.upper_case) {
    buffer[i] = 'x';
    i++;
    size_to_num--;
    buffer[i] = '0';
    i++;
    size_to_num--;
  }

  // обработка ситуации, когда осталось свободное место в строке
  if (size_to_num > 0 && specs.minus == 0) {
    while ((size_to_num - specs.flag_to_size > 0) && buffer) {
      buffer[i] = ' ';
      i++;
      size_to_num;
    }
  }
  return i;
}


char get_num_char(
    int num,
    int upper_case) {  // num остаток от деления преобразовывает в символ
  char flag = '0';
  switch (num) {
    case 10:
      flag = (char)('a' - upper_case * 32);
      break;
    case 11:
      flag = (char)('b' - upper_case * 32);
      break;
    case 12:
      flag = (char)('c' - upper_case * 32);
      break;
    case 13:
      flag = (char)('d' - upper_case * 32);
      break;
    case 14:
      flag = (char)('e' - upper_case * 32);
      break;
    case 15:
      flag = (char)('f' - upper_case * 32);
      break;
  }
  if (0 <= num && num <= 9) flag = (char)(num + 48);  // 48 =='0'
  return flag;
}

// для рассчета размера для буфера
s21_size_t get_buf_size_unsigned_decimal(Spec specs, unsigned long int num) {
  s21_size_t result = 0;

  // Рассчитываем размер на основе числа и спецификаций
  unsigned long int copy_num = num;
  while (copy_num > 0) {
    copy_num /= specs.number_system;
    result++;
  }

  // Обрабатываем специальные случаи
  if (result == 0 && copy_num == 0 &&
      (specs.accuracy || specs.width || specs.space)) {
    result++;
  }
  if ((s21_size_t)specs.width > result) {
    result = specs.width;
  }
  if (specs.space || num > 0) {
    specs.flag_to_size = 1;
    result++;
  }
  return result;
}
/*char print_c(char *str, Spec specs, int symbol) {  // обработка чаров
 char *ptr = S21_NULL;
  int i = 0;
  while (specs.width - 1 > 0 &&
         !specs.minus) {  // пробелы перед символом // - 1
                          // резервация для нашего символа
    *str = ' ';
    str++;
    i++;
    specs.width--;
  }
  if (symbol <= 127) {
    *str = symbol;
    str++;
    i++;
    while (specs.width - 1 > 0 &&
           specs.minus) {  // пробелы с минусом после символа
      *str = ' ';
      str++;
      i++;
      specs.width--;
    }
    ptr = str;  // возвращем указатель
  }
  return str;
}*/



/*char *print_c(char *str, Spec specs, int symbol) {
  char *ptr = S21_NULL;
  int i = 0;
  
  while (specs.width - 1 > 0 && !specs.minus) {
    *str = ' ';
    str++;
    i++;
    specs.width--;
  }

  if (symbol <= 127) {
    *str = symbol;
    str++;
    i++;
  }

  while (specs.width - 1 > 0 && specs.minus) {
    *str = ' ';
    str++;
    i++;
    specs.width--;
  }

  ptr = str;  // возвращаем указатель
  return ptr;
}*/

char *print_c(char *str, Spec specs, int symbol) {  // обработка чаров
    char *ptr = S21_NULL;
    int i = 0;
    while (specs.width - 1 > 0 &&
           !specs.minus) {  // пробелы перед символом // - 1
                            // резервация для нашего символа
        *str = ' ';
        str++;
        i++;
        specs.width--;
    }
    if (symbol <= 127) {
        *str = (char)symbol;  // приводим к типу char
        str++;
        i++;
        while (specs.width - 1 > 0 &&
               specs.minus) {  // пробелы с минусом после символа
            *str = ' ';
            str++;
            i++;
            specs.width--;
        }
        ptr = str;  // возвращаем указатель
    }
    return ptr;  // возвращаем указатель
}


char *print_s(char *str, Spec specs, va_list *arguments) {
  char *ptr = str;
  int i = 0;
  char *string = va_arg(*arguments, char *);
  if (string) {
    int width = specs.width;  // для проверки ширины, если она не указана или
                              // меньше длины строки

    if ((s21_size_t)width < s21_strlen(string))
      specs.width = s21_strlen(string);  // то она равна длине строки

    int number_of_spaces =
        specs.width - s21_strlen(string);  // если ширина больше строки

    // Если есть точность, и она меньше ширины, то количество пробелов меняется
    if (specs.accuracy != 0 && specs.accuracy < width)
      number_of_spaces = width - specs.accuracy;

    // если нет минусв
    while (number_of_spaces && !specs.minus) {
      *str = ' ';
      str++;
      number_of_spaces--;
    }

    // посимвольная запись из стринг в стр
    while (*string != '\0') {
      if (!specs.accuracy) break;
      *str = *string;
      str++;
      string++;
      specs.accuracy--;
    }

    // если есть минус
    while (number_of_spaces && specs.minus) {
      *str = ' ';
      str++;
      number_of_spaces--;
    }

    // если не удалось получить строку, записываем NULL
  } else {
    str = s21_memcpy(str, "(null)", 6);
    str = str + 6;
  }
  // возвращаем указатель

  if (ptr) ptr = str;
  return ptr;
}
// обаботка p
char *print_p(char *str, Spec *specs, va_list *arguments) {
  // получаю из аргументов адресс
  unsigned long int ptr =
      (unsigned long int)va_arg(*arguments, unsigned long int);
  // устанавливаю парметры для 16 системы
  specs->number_system = 16;
  specs->hash = 1;
  specs->upper_case = 0;

  s21_size_t size_to_num = get_buf_size_unsigned_decimal(*specs, ptr);
  char *buffer = malloc(sizeof(char) * size_to_num);
  if (buffer) {
    int i = unsigned_decimal_to_string(buffer, *specs, ptr, size_to_num);

    str += add_buffer_to_string(specs->width, &i, buffer,
                                str);  // копируем число в стр
  }
  if (buffer) free(buffer);
  return str;
}
Spec set_spec_for_double(Spec specs, char format) {
  if (format == 'g' || format == 'G')
    specs.g = 1;
  else if (format == 'e' || format == 'E')
    specs.e = 1;
  if (format == 'G' || format == 'E' || format == 'F') specs.upper_case = 1;
  return specs;
}

char *print_double(char *str, Spec specs, char format, va_list *arguments) {
  long double num = 0;
  int e = 0;
  if (format == 'L') {
    num = va_arg(*arguments, long double);
  } else
  num = va_arg(*arguments, double);
}