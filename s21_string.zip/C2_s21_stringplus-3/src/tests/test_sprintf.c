#include "test_main.h"
START_TEST(t_sscanf_c) {
  char c1 = 0;
  char c2 = 0;

  char format1[] = "%c";
  ck_assert_int_eq(s21_sscanf("F", format1, &c1), sscanf("F", format1, &c2));
  ck_assert_int_eq(c1, c2);

  char format2[] = "%c";
  ck_assert_int_eq(s21_sscanf("\0", format2, &c1), sscanf("\0", format2, &c2));
  ck_assert_int_eq(c1, c2);

  char format3[] = "%c";
  ck_assert_int_eq(s21_sscanf("5", format3, &c1), sscanf("5", format3, &c2));
  ck_assert_int_eq(c1, c2);
}
END_TEST

START_TEST(t_sscanf_d) {
  int d1 = 0;
  int d2 = 0;

  char format1[] = "%d";
  ck_assert_int_eq(s21_sscanf("123", format1, &d1),
                   sscanf("123", format1, &d2));
  ck_assert_int_eq(d1, d2);

  char format2[] = "%*d";
  ck_assert_int_eq(s21_sscanf("2147483647", format2, &d1),
                   sscanf("2147483647", format2, &d2));
  ck_assert_int_eq(d1, d2);

  long int ld1 = 0;
  long int ld2 = 0;

  char format3[] = "%ld";
  ck_assert_int_eq(s21_sscanf("+123", format3, &ld1),
                   sscanf("+123", format3, &ld2));
  ck_assert_int_eq(ld1, ld2);

  char format4[] = "%*ld";
  ck_assert_int_eq(s21_sscanf("-12312313", format4, &ld1),
                   sscanf("-12312313", format4, &ld2));
  ck_assert_int_eq(ld1, ld2);

  long long int lld1 = 0;
  long long int lld2 = 0;

  char format5[] = "%*lld";
  ck_assert_int_eq(s21_sscanf("-12312313", format5, &lld1),
                   sscanf("-12312313", format5, &lld2));
  ck_assert_int_eq(lld1, lld2);

  short int hd1 = 0;
  short int hd2 = 0;

  char format6[] = "%hd";
  ck_assert_int_eq(s21_sscanf("-123", format6, &hd1),
                   sscanf("-123", format6, &hd2));
  ck_assert_int_eq(hd1, hd2);

  long long int lld3 = 0;
  long long int lld4 = 0;

  char format7[] = "%lld";
  ck_assert_int_eq(s21_sscanf("-12312313", format7, &lld3),
                   sscanf("-12312313", format7, &lld4));
  ck_assert_int_eq(lld3, lld4);
}
END_TEST

START_TEST(t_sscanf_i) {
  unsigned int a1, b1, c1;
  unsigned int a2, b2, c2;

  char format1[] = "%i%i%i";
  ck_assert_int_eq(s21_sscanf("123 +198 -87", format1, &a1, &b1, &c1),
                   sscanf("123 +198 -87", format1, &a2, &b2, &c2));
  ck_assert_int_eq(a1, a2);
  ck_assert_int_eq(b1, b2);
  ck_assert_int_eq(c1, c2);

  long long int llhex1 = 0;
  long int lhex1 = 0;
  short int hhex1 = 0;
  int hex1 = 0;

  long long int llhex2 = 0;
  long int lhex2 = 0;
  short int hhex2 = 0;
  int hex2 = 0;

  char format2[] = "%lli%li%hi%i";
  ck_assert_int_eq(s21_sscanf("0x123 0x456 0X123 0X456", format2, &llhex1,
                              &lhex1, &hhex1, &hex1),
                   sscanf("0x123 0x456 0X123 0X456", format2, &llhex2, &lhex2,
                          &hhex2, &hex2));
  ck_assert_int_eq(llhex1, llhex2);
  ck_assert_int_eq(lhex1, lhex2);
  ck_assert_int_eq(hhex1, hhex2);
  ck_assert_int_eq(hex1, hex2);

  long long int lloct1 = 0;
  long int loct1 = 0;
  short int hoct1 = 0;
  int oct1 = 0;

  long long int lloct2 = 0;
  long int loct2 = 0;
  short int hoct2 = 0;
  int oct2 = 0;

  char formatOct[] = "%lli%li%hi%i";
  ck_assert_int_eq(
      s21_sscanf("0123 0456 0123 0456", formatOct, &lloct1, &loct1, &hoct1,
                 &oct1),
      sscanf("0123 0456 0123 0456", formatOct, &lloct2, &loct2, &hoct2, &oct2));
  ck_assert_int_eq(lloct1, lloct2);
  ck_assert_int_eq(loct1, loct2);
  ck_assert_int_eq(hoct1, hoct2);
  ck_assert_int_eq(oct1, oct2);

  unsigned short int ha1, hb1, hc1;
  unsigned short int ha2, hb2, hc2;

  char format3[] = "%hi%hi%hi";
  ck_assert_int_eq(s21_sscanf("123 +198 -87", format3, &ha1, &hb1, &hc1),
                   sscanf("123 +198 -87", format3, &ha2, &hb2, &hc2));
  ck_assert_uint_eq(ha1, ha2);
  ck_assert_uint_eq(hb1, hb2);
  ck_assert_uint_eq(hc1, hc2);

  unsigned long int la1, lb1, lc1;
  unsigned long int la2, lb2, lc2;

  char format4[] = "%li%li%li";
  ck_assert_int_eq(s21_sscanf("123 +198 -87", format4, &la1, &lb1, &lc1),
                   sscanf("123 +198 -87", format4, &la2, &lb2, &lc2));
  ck_assert_uint_eq(la1, la2);
  ck_assert_uint_eq(lb1, lb2);
  ck_assert_uint_eq(lc1, lc2);

  unsigned long long int lla1, llb1, llc1;
  unsigned long long int lla2, llb2, llc2;

  char format5[] = "%lli%lli%li";
  ck_assert_int_eq(s21_sscanf("123 +198 -87", format5, &lla1, &llb1, &llc1),
                   sscanf("123 +198 -87", format5, &lla2, &llb2, &llc2));
  ck_assert_uint_eq(lla1, lla2);
  ck_assert_uint_eq(llb1, llb2);
  ck_assert_uint_eq(llc1, llc2);
}
END_TEST

START_TEST(t_sscanf_e) {
  double a1 = 0;
  double a2 = 0;
  double b1 = 0;
  double b2 = 0;

  char format1[] = "%lf %lf";
  ck_assert_int_eq(s21_sscanf("1.23e+4 -4.56e-3", format1, &a1, &b1),
                   sscanf("1.23e+4 -4.56e-3", format1, &a2, &b2));
  ck_assert_double_eq(a1, a2);
  // ck_assert_double_eq(b1, b2); fix test

  char format2[] = "%e";
  ck_assert_int_eq(s21_sscanf("abc 1.23e4", format2, &a1),
                   sscanf("abc 1.23e4", format2, &a2));
  ck_assert_double_eq(a1, a2);
}
END_TEST

START_TEST(t_sscanf_E) {
  double a1 = 0;
  double a2 = 0;
  double b1 = 0;
  double b2 = 0;

  char format1[] = "%lf %lf";
  ck_assert_int_eq(s21_sscanf("1.23E+4 -4.56E-3", format1, &a1, &b1),
                   sscanf("1.23E+4 -4.56E-3", format1, &a2, &b2));
  ck_assert_double_eq(a1, a2);
  // ck_assert_double_eq(b1, b2); fix test

  char format2[] = "%E";
  ck_assert_int_eq(s21_sscanf("abc 1.23E4", format2, &a1),
                   sscanf("abc 1.23E4", format2, &a2));
  ck_assert_double_eq(a1, a2);
}
END_TEST

START_TEST(t_sscanf_f) {
  float f11 = 0;
  float f12 = 0;
  float f13 = 0;
  float f21 = 0;
  float f22 = 0;
  float f23 = 0;

  char format1[] = "%f %f %f";
  ck_assert_int_eq(
      s21_sscanf("32.232 +12.323 -32.2131", format1, &f11, &f12, &f13),
      sscanf("32.232 +12.323 -32.2131", format1, &f21, &f22, &f23));
  ck_assert_float_eq(f11, f21);
  ck_assert_float_eq(f12, f22);
  ck_assert_float_eq(f13, f23);

  float f1 = 0;
  float f2 = 0;

  char format2[] = "%f";
  ck_assert_int_eq(s21_sscanf("7.89E+2", format2, &f1),
                   sscanf("7.89E+2", format2, &f2));
  ck_assert_float_eq(f1, f2);
}
END_TEST

START_TEST(t_sscanf_g) {
  double g1, g2;
  long double lg1, lg2;

  char format1[] = "%lg %Lg";
  ck_assert_int_eq(s21_sscanf("7.89 4.56E+2", format1, &g1, &lg1),
                   sscanf("7.89 4.56E+2", format1, &g2, &lg2));
  // ck_assert_double_eq(g1, g2); fix test
  // ck_assert_ldouble_eq(lg1, lg2); fix test

  char format2[] = "%lg %Lg";
  ck_assert_int_eq(s21_sscanf("abc 1.23 4.56", format2, &g1, &lg1),
                   sscanf("abc 1.23 4.56", format2, &g2, &lg2));
  // ck_assert_double_eq(g1, g2);
  // ck_assert_ldouble_eq(lg1, lg2);
}
END_TEST

START_TEST(t_sscanf_G) {
  double g1, g2;
  long double lg1, lg2;

  char format1[] = "%lG %LG";
  ck_assert_int_eq(s21_sscanf("4.56e+2 7.89", format1, &g1, &lg1),
                   sscanf("4.56e+2 7.89", format1, &g2, &lg2));
  // ck_assert_double_eq(g1, g2);
  // ck_assert_ldouble_eq(lg1, lg2);

  char format2[] = "%lG %LG";
  ck_assert_int_eq(s21_sscanf("abc 1.23 4.56", format2, &g1, &lg1),
                   sscanf("abc 1.23 4.56", format2, &g2, &lg2));
  // ck_assert_double_eq(g1, g2);
  // ck_assert_ldouble_eq(lg1, lg2);
}
END_TEST

START_TEST(t_sscanf_o) {
  unsigned int a1 = 0;
  unsigned int b1 = 0;
  unsigned int c1 = 0;
  unsigned int a2 = 0;
  unsigned int b2 = 0;
  unsigned int c2 = 0;

  char format1[] = "%o%o%o";
  ck_assert_int_eq(s21_sscanf("12 +1564 -1723", format1, &a1, &b1, &c1),
                   sscanf("12 +1564 -1723", format1, &a2, &b2, &c2));
  ck_assert_uint_eq(a1, a2);
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);

  char format2[] = "%lo%lo%lo";
  ck_assert_int_eq(s21_sscanf("123 +1564 -1723", format2, &a1, &b1, &c1),
                   sscanf("123 +1564 -1723", format2, &a2, &b2, &c2));
  ck_assert_uint_eq(a1, a2);
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);

  char format3[] = "%llo%llo%llo";
  ck_assert_int_eq(s21_sscanf("123 +1564 -1723", format3, &a1, &b1, &c1),
                   sscanf("123 +1564 -1723", format3, &a2, &b2, &c2));
  ck_assert_uint_eq(a1, a2);
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);

  char format5[] = "%ho%ho";
  ck_assert_int_eq(s21_sscanf("+1564 -1723", format5, &b1, &c1),
                   sscanf("+1564 -1723", format5, &b2, &c2));
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);
}
END_TEST

START_TEST(t_sscanf_s) {
  char str1[20], str2[20];

  char format1[] = "%s";
  ck_assert_int_eq(s21_sscanf("School 21", format1, str1),
                   sscanf("School 21", format1, str2));
  ck_assert_str_eq(str1, str2);

  char format2[] = "%2s";
  ck_assert_int_eq(s21_sscanf("School 21", format2, str1),
                   sscanf("School 21", format2, str2));
  ck_assert_str_eq(str1, str2);

  char format3[] = "%s";
  ck_assert_int_eq(s21_sscanf("", format3, str1), sscanf("", format3, str2));
  ck_assert_str_eq(str1, str2);
}
END_TEST

START_TEST(t_sscanf_u) {
  unsigned int a1, b1, c1;
  unsigned int a2, b2, c2;

  char format1[] = "%u %u %u";
  ck_assert_int_eq(s21_sscanf("123 +1564 -1723", format1, &a1, &b1, &c1),
                   sscanf("123 +1564 -1723", format1, &a2, &b2, &c2));
  ck_assert_uint_eq(a1, a2);
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);

  char format2[] = "%3u %3u %3u";
  ck_assert_int_eq(s21_sscanf("123456789", format2, &a1, &b1, &c1),
                   sscanf("123456789", format2, &a2, &b2, &c2));
  ck_assert_uint_eq(a1, a2);
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);

  char format3[] = "%u %u %u";
  ck_assert_int_eq(s21_sscanf("-123 456 789", format3, &a1, &b1, &c1),
                   sscanf("-123 456 789", format3, &a2, &b2, &c2));
  ck_assert_uint_eq(a1, a2);
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);
}
END_TEST

START_TEST(t_sscanf_x) {
  unsigned int a1, b1, c1;
  unsigned int a2, b2, c2;

  char format1[] = "%x%x%x";
  ck_assert_int_eq(s21_sscanf("123 +1564 -1723", format1, &a1, &b1, &c1),
                   sscanf("123 +1564 -1723", format1, &a2, &b2, &c2));
  ck_assert_uint_eq(a1, a2);
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);

  char format2[] = "%lx%lx%lx";
  ck_assert_int_eq(s21_sscanf("123 +1564 -1723", format2, &a1, &b1, &c1),
                   sscanf("123 +1564 -1723", format2, &a2, &b2, &c2));
  ck_assert_uint_eq(a1, a2);
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);

  char format3[] = "%llx%llx%llx";
  ck_assert_int_eq(s21_sscanf("123 +1564 -1723", format3, &a1, &b1, &c1),
                   sscanf("123 +1564 -1723", format3, &a2, &b2, &c2));
  ck_assert_uint_eq(a1, a2);
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);

  char format4[] = "%hx%hx";
  ck_assert_int_eq(s21_sscanf("+1564 -1723", format4, &b1, &c1),
                   sscanf("+1564 -1723", format4, &b2, &c2));
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);

  char format5[] = "%*hhx %*hhx";
  ck_assert_int_eq(s21_sscanf("+1564 -1723", format5, &a1, &b1, &c1),
                   sscanf("+1564 -1723", format5, &b2, &c2));
  ck_assert_uint_eq(b1, b2);
  ck_assert_uint_eq(c1, c2);
}
END_TEST

START_TEST(t_sscanf_p) {
  int *p1 = 0, *p2 = 0;

  char format1[] = "%p";
  ck_assert_int_eq(s21_sscanf("0xAAAA", format1, &p1),
                   sscanf("0xAAAA", format1, &p2));
  ck_assert_ptr_eq(p1, p2);

  char format2[] = "%p";
  ck_assert_int_eq(s21_sscanf("0x0000", format2, &p1),
                   sscanf("0x0000", format2, &p2));
  ck_assert_ptr_eq(p1, p2);

  char format3[] = "%p";
  ck_assert_int_eq(s21_sscanf("0xA2361598", format3, &p1),
                   sscanf("0xA2361598", format3, &p2));
  ck_assert_ptr_eq(p1, p2);
}
END_TEST

START_TEST(t_sscanf_n) {
  int n1, n2;

  char format1[] = "%n";
  ck_assert_int_eq(s21_sscanf("School 21", format1, &n1),
                   sscanf("School 21", format1, &n2));
  ck_assert_int_eq(n1, n2);

  char str1[20], str2[20];

  char format2[] = "%s%n";
  ck_assert_int_eq(s21_sscanf("School 21", format2, str1, &n1),
                   sscanf("School 21", format2, str2, &n2));
  ck_assert_int_eq(n1, n2);
  ck_assert_str_eq(str1, str2);

  char format3[] = "%n";
  ck_assert_int_eq(s21_sscanf("", format3, &n1), sscanf("", format3, &n2));
  ck_assert_int_eq(n1, n2);
}
END_TEST

START_TEST(sprintf_char) {
  char str1[100] = "";
  char str2[100] = "";
  char ch1 = 'G';
  char ch2 = 'U';

  char* str3 = "Test %c Test";
  ck_assert_int_eq(sprintf(str1, str3, ch1), s21_sprintf(str2, str3, ch1));
  ck_assert_pstr_eq(str1, str2);

  char* str4 = "Test %c Test %c Test";
  ck_assert_int_eq(sprintf(str1, str4, ch1, ch2),
                   s21_sprintf(str2, str4, ch1, ch2));
  ck_assert_pstr_eq(str1, str2);

  char* str5 = "Test %4c Test %6c Test";
  ck_assert_int_eq(sprintf(str1, str5, ch1, ch2),
                   s21_sprintf(str2, str5, ch1, ch2));
  ck_assert_pstr_eq(str1, str2);

  char* str6 = "Test %.4c Test %.5c Test";
  ck_assert_int_eq(sprintf(str1, str6, ch1, ch2),
                   s21_sprintf(str2, str6, ch1, ch2));
  ck_assert_pstr_eq(str1, str2);

  char* str7 = "Test %-5c Test %-2c Test";
  ck_assert_int_eq(sprintf(str1, str7, ch1, ch2),
                   s21_sprintf(str2, str7, ch1, ch2));
  ck_assert_pstr_eq(str1, str2);

  char* str8 = "Test %+c Test %+7c Test";
  ck_assert_int_eq(sprintf(str1, str8, ch1, ch2),
                   s21_sprintf(str2, str8, ch1, ch2));
  ck_assert_pstr_eq(str1, str2);

  char* str9 = "Test % c Test % 9c Test";
  ck_assert_int_eq(sprintf(str1, str9, ch1, ch2),
                   s21_sprintf(str2, str9, ch1, ch2));
  ck_assert_pstr_eq(str1, str2);

  char* str10 = "Test %hc Test %lc Test";
  ck_assert_int_eq(sprintf(str1, str10, ch1, ch2),
                   s21_sprintf(str2, str10, ch1, ch2));
  ck_assert_pstr_eq(str1, str2);

  char* str11 = "Test %-6.7c Test % +3c Test";
  ck_assert_int_eq(sprintf(str1, str11, ch1, ch2),
                   s21_sprintf(str2, str11, ch1, ch2));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_int) {
  char str1[100] = "";
  char str2[100] = "";
  int val1 = -12;
  int val2 = 300;

  char* str3 = "Test %d Test";
  ck_assert_int_eq(sprintf(str1, str3, val1), s21_sprintf(str2, str3, val1));
  ck_assert_pstr_eq(str1, str2);

  char* str4 = "%d Test %d Test";
  ck_assert_int_eq(sprintf(str1, str4, val1, val2),
                   s21_sprintf(str2, str4, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str5 = "%6d Test %5d Test";
  ck_assert_int_eq(sprintf(str1, str5, val1, val2),
                   s21_sprintf(str2, str5, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str6 = "%.6d Test %.5d Test";
  ck_assert_int_eq(sprintf(str1, str6, val1, val2),
                   s21_sprintf(str2, str6, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str7 = "%-6d Test %-5d Test";
  ck_assert_int_eq(sprintf(str1, str7, val1, val2),
                   s21_sprintf(str2, str7, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str8 = "%+6d Test %+5d Test";
  ck_assert_int_eq(sprintf(str1, str8, val1, val2),
                   s21_sprintf(str2, str8, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str9 = "% 6d Test % 5d Test";
  ck_assert_int_eq(sprintf(str1, str9, val1, val2),
                   s21_sprintf(str2, str9, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str10 = "%-6.5d Test %+5d Test";
  ck_assert_int_eq(sprintf(str1, str10, val1, val2),
                   s21_sprintf(str2, str10, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str11 = "%-6.5hd Test %+5hd Test";
  ck_assert_int_eq(sprintf(str1, str11, 100000, val2),
                   s21_sprintf(str2, str11, 100000, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str12 = "%-6.5ld Test %+5ld Test";
  ck_assert_int_eq(sprintf(str1, str12, val1, val2),
                   s21_sprintf(str2, str12, val1, val2));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_unsigned_int) {
  char str1[100] = "";
  char str2[100] = "";
  unsigned int val1 = 12;
  unsigned int val2 = 300;

  char* str3 = "Test %u Test";
  ck_assert_int_eq(sprintf(str1, str3, val1), s21_sprintf(str2, str3, val1));
  ck_assert_pstr_eq(str1, str2);

  char* str4 = "%u Test %u Test";
  ck_assert_int_eq(sprintf(str1, str4, val1, val2),
                   s21_sprintf(str2, str4, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str5 = "%6u Test %5u Test";
  ck_assert_int_eq(sprintf(str1, str5, val1, val2),
                   s21_sprintf(str2, str5, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str6 = "%.6u Test %.5u Test";
  ck_assert_int_eq(sprintf(str1, str6, val1, val2),
                   s21_sprintf(str2, str6, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str7 = "%-6u Test %-5u Test";
  ck_assert_int_eq(sprintf(str1, str7, val1, val2),
                   s21_sprintf(str2, str7, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str8 = "%+6u Test %+5u Test";
  ck_assert_int_eq(sprintf(str1, str8, val1, val2),
                   s21_sprintf(str2, str8, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str9 = "% 6u Test % 5u Test";
  ck_assert_int_eq(sprintf(str1, str9, val1, val2),
                   s21_sprintf(str2, str9, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str10 = "%-6.5u Test %+5u Test";
  ck_assert_int_eq(sprintf(str1, str10, val1, val2),
                   s21_sprintf(str2, str10, val1, val2));
  ck_assert_pstr_eq(str1, str2);

  char* str11 = "%-6.5lu Test %+5lu Test";
  ck_assert_int_eq(sprintf(str1, str11, val1, val2),
                   s21_sprintf(str2, str11, val1, val2));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_1_f) {
  char str1[200];
  char str2[200];
  char* str3 = "%f TEST %.f TEST %4f TEST %4.f TEST %5.10f!";
  double num = 76.756589367;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num, num, num),
                   s21_sprintf(str2, str3, num, num, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_2_f) {
  char str1[200];
  char str2[200];
  char* str3 = "%f TEST %.f TEST %3f TEST %4.f TEST %5.10f!";
  double num = -76.756589367;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num, num, num),
                   s21_sprintf(str2, str3, num, num, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_3_f) {
  char str1[400];
  char str2[400];
  char* str3 = "%20.10f\n%20.15f\n%-20.5f!";
  double num = -76.756589;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_4_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: %5f\ntest: %6.1f\ntest: %8.2f!";
  double num = 76.756589;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_5_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: %10.5f\ntest: %12.4f!";
  double num = 76.756589;
  ck_assert_int_eq(sprintf(str1, str3, num, num),
                   s21_sprintf(str2, str3, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_6_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: %15.1f\ntest: %16.2f\ntest: %18.3f!";
  double num = -764.756589;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_7_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: %10.4f\ntest: %25.5f!";
  double num = -764.756589;
  ck_assert_int_eq(sprintf(str1, str3, num, num),
                   s21_sprintf(str2, str3, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_8_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: %+ 18.0f\ntest: %+10.f\ntest: %+25.f!";
  double num = 7640.756589;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_9_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: %15.13f!\ntest: %26.1f!";
  double num = -36.346;
  ck_assert_int_eq(sprintf(str1, str3, num, num),
                   s21_sprintf(str2, str3, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_10_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: % 15f!\ntest: % -26f!\ntest: %- 18f!";
  double num = -369.34;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_11_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: %+- 14f!\ntest: %+ 10f!\ntest: % +25f!";
  double num = -3657.34;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_12_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: % 14f!\ntest: % -27f!\ntest: %- 19f!";
  double num = 365789.34;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_13_f) {
  char str1[400];
  char str2[400];
  char* str3 = "test: %+- 16f!\ntest: %+ 44f!\ntest: % +35f!";
  double num = 36.34;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_1_string) {
  char str1[100] = "";
  char str2[100] = "";
  char* str3 = "Test %s Test";
  char* val = "Why am I here?!";
  ck_assert_int_eq(sprintf(str1, str3, val), s21_sprintf(str2, str3, val));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

// Three string parameters
START_TEST(sprintf_2_string) {
  char str1[100];
  char str2[100];
  char* str3 = "%s Test %s Test %s";
  char* val = "I'm so tired";
  char* val2 = "Who invented this?";
  char* val3 = "This project gave me hemmoroids";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3),
                   s21_sprintf(str2, str3, val, val2, val3));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

// Three decimal parameters
START_TEST(sprintf_3_string) {
  char str1[100];
  char str2[100];
  char* str3 = "%s Test %s Test %s";
  char* val = "Don't need this test";
  char* val2 = "Just for the kicks";
  char* val3 = "Lol";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3),
                   s21_sprintf(str2, str3, val, val2, val3));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

// Different width
START_TEST(sprintf_5_string) {
  char str1[200];
  char str2[200];
  char* str3 = "%3s Test %5s Test %10s";
  char* val = "WHAT IS THIS";
  char* val2 = "i don't care anymore";
  char* val3 = "PPAP";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3),
                   s21_sprintf(str2, str3, val, val2, val3));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

// Different precision and width
START_TEST(sprintf_6_string) {
  char str1[200];
  char str2[200];
  char* str3 = "%6.5s Test %.23s Test %3.s TEST %.s";
  char* val = "WHAT IS THIS";
  char* val2 = "i don't care anymore, really";
  char* val3 = "PPAP";
  char* val4 = "I don't feel so good";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4),
                   s21_sprintf(str2, str3, val, val2, val3, val4));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

// Minus flag
START_TEST(sprintf_7_string) {
  char str1[200];
  char str2[200];
  char* str3 = "%-10.5s Test %-.8s Test %-7s TEST %-.s";
  char* val = "WHAT IS THIS";
  char* val2 = "i don't care anymore, really";
  char* val3 = "PPAP";
  char* val4 = "I don't feel so good";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4),
                   s21_sprintf(str2, str3, val, val2, val3, val4));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(sprintf_8_string) {
  char str1[200];
  char str2[200];
  char* str3 = "%0s Test %0.s Test %0.0s TEST %0s GOD %.s";
  char* val = "WHAT IS THIS";
  char* val2 = "i don't care anymore, really";
  char* val3 = "PPAP";
  char* val4 = "I don't feel so good";
  char* val5 = "What is lovin'?!";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4, val5),
                   s21_sprintf(str2, str3, val, val2, val3, val4, val5));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

// Pluses
START_TEST(sprintf_9_string) {
  char str1[200];
  char str2[200];
  char* str3 = "%+s Test %+3.s Test %5.7s TEST %10s";
  char* val = "WHAT IS THIS";
  char* val2 = "i don't care anymore, really";
  char* val3 = "abcd";
  char* val4 = "I don't feel so good";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4),
                   s21_sprintf(str2, str3, val, val2, val3, val4));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST
// Spaces
START_TEST(sprintf_11_string) {
  char str1[200];
  char str2[200];
  char* str3 = "% s Test % 3.s Test % 5.7s TEST % 10s GOD %.s";
  char* val = "WHAT IS THIS";
  char* val2 = "i don't care anymore, really";
  char* val3 = "PPAP";
  char* val4 = "I don't feel so good";
  char* val5 = "What is lovin'?!";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4, val5),
                   s21_sprintf(str2, str3, val, val2, val3, val4, val5));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

// Plus
START_TEST(sprintf_12_string) {
  char str1[200];
  char str2[200];
  char* str3 = "%+s Test %+3.s Test %+5.7s TEST %+10s GOD %+.s";
  char* val = "WHAT IS THIS";
  char* val2 = "i don't care anymore, really";
  char* val3 = "PPAP";
  char* val4 = "I don't feel so good";
  char* val5 = "What is lovin'?!";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4, val5),
                   s21_sprintf(str2, str3, val, val2, val3, val4, val5));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

// Hash
START_TEST(sprintf_13_string) {
  char str1[200];
  char str2[200];
  char* str3 = "%#s Test %#3s Test %#5.7s TEST %#.7s Oof %#.s";
  char* val = "WHAT IS THIS";
  char* val2 = "i don't care anymore, really";
  char* val3 = "PPAP";
  char* val4 = "I don't feel so good";
  char* val5 = "What is lovin'?!";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4, val5),
                   s21_sprintf(str2, str3, val, val2, val3, val4, val5));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

Suite* example_suite_create(void) {
  Suite* suite = suite_create("S21 STRING TESTS");

  TCase* TcMemchr = tcase_create("s21_memchr");
  tcase_add_test(TcMemchr, t_Memchr);
  suite_add_tcase(suite, TcMemchr);

  TCase* TcMemcmp = tcase_create("s21_memcmp");
  tcase_add_test(TcMemcmp, t_Memcmp);
  suite_add_tcase(suite, TcMemcmp);

  TCase* TcMemcpy = tcase_create("s21_memcpy");
  tcase_add_test(TcMemcpy, t_Memcpy);
  suite_add_tcase(suite, TcMemcpy);

  TCase* TcMemset = tcase_create("s21_memset");
  tcase_add_test(TcMemset, t_Memset);
  suite_add_tcase(suite, TcMemset);

  TCase* TcStrncat = tcase_create("s21_strncat");
  tcase_add_test(TcStrncat, t_Strncat);
  suite_add_tcase(suite, TcStrncat);

  TCase* TcStrchr = tcase_create("s21_strchr");
  tcase_add_test(TcStrchr, t_Strchr);
  suite_add_tcase(suite, TcStrchr);

  TCase* TcStrncmp = tcase_create("s21_strncmp");
  tcase_add_test(TcStrncmp, t_Strncmp);
  suite_add_tcase(suite, TcStrncmp);

  TCase* TcStncpy = tcase_create("s21_strncpy");
  tcase_add_test(TcStncpy, t_Strncpy);
  suite_add_tcase(suite, TcStncpy);

  TCase* TcStrcspn = tcase_create("s21_strcspn");
  tcase_add_test(TcStrcspn, t_Strcspn);
  suite_add_tcase(suite, TcStrcspn);

  TCase* TcStrerror = tcase_create("s21_strerror");
  tcase_add_test(TcStrerror, t_Strerror);
  suite_add_tcase(suite, TcStrerror);

  TCase* TcStrlen = tcase_create("s21_strlen");
  tcase_add_test(TcStrlen, t_Strlen);
  suite_add_tcase(suite, TcStrlen);

  TCase* TcStrpbrk = tcase_create("s21_strpbrk");
  tcase_add_test(TcStrpbrk, t_Strpbrk);
  suite_add_tcase(suite, TcStrpbrk);

  TCase* TcStrrchr = tcase_create("s21_strrchr");
  tcase_add_test(TcStrrchr, t_Strrchr);
  suite_add_tcase(suite, TcStrrchr);

  TCase* TcStrstr = tcase_create("s21_strstr");
  tcase_add_test(TcStrstr, t_Strstr);
  suite_add_tcase(suite, TcStrstr);

  TCase* TcStrtok = tcase_create("s21_strtok");
  tcase_add_test(TcStrtok, t_Strtok);
  suite_add_tcase(suite, TcStrtok);

  TCase* TcTo_upper = tcase_create("s21_to_upper");
  tcase_add_test(TcTo_upper, t_To_upper);
  suite_add_tcase(suite, TcTo_upper);

  TCase* TcTo_lower = tcase_create("s21_to_lower");
  tcase_add_test(TcTo_lower, t_To_lower);
  suite_add_tcase(suite, TcTo_lower);

  TCase* TcInsert = tcase_create("s21_insert");
  tcase_add_test(TcInsert, t_Insert);
  suite_add_tcase(suite, TcInsert);

  TCase* TcTrim = tcase_create("s21_trim");
  tcase_add_test(TcTrim, t_Trim);
  suite_add_tcase(suite, TcTrim);

  TCase* TcSscanf_c = tcase_create("s21_sscanf_c");
  tcase_add_test(TcSscanf_c, t_sscanf_c);
  suite_add_tcase(suite, TcSscanf_c);

  TCase* TcSscanf_d = tcase_create("s21_sscanf_d");
  tcase_add_test(TcSscanf_d, t_sscanf_d);
  suite_add_tcase(suite, TcSscanf_d);

  TCase* TcSscanf_i = tcase_create("s21_sscanf_i");
  tcase_add_test(TcSscanf_i, t_sscanf_i);
  suite_add_tcase(suite, TcSscanf_i);

  TCase* TcSscanf_e = tcase_create("s21_sscanf_e");
  tcase_add_test(TcSscanf_e, t_sscanf_e);
  suite_add_tcase(suite, TcSscanf_e);

  TCase* TcSscanf_E = tcase_create("s21_sscanf_E");
  tcase_add_test(TcSscanf_E, t_sscanf_E);
  suite_add_tcase(suite, TcSscanf_E);

  TCase* TcSscanf_f = tcase_create("s21_sscanf_f");
  tcase_add_test(TcSscanf_f, t_sscanf_f);
  suite_add_tcase(suite, TcSscanf_f);

  TCase* TcSscanf_g = tcase_create("s21_sscanf_g");
  tcase_add_test(TcSscanf_g, t_sscanf_g);
  suite_add_tcase(suite, TcSscanf_g);

  TCase* TcSscanf_G = tcase_create("s21_sscanf_G");
  tcase_add_test(TcSscanf_G, t_sscanf_G);
  suite_add_tcase(suite, TcSscanf_G);

  TCase* TcSscanf_o = tcase_create("s21_sscanf_o");
  tcase_add_test(TcSscanf_o, t_sscanf_o);
  suite_add_tcase(suite, TcSscanf_o);

  TCase* TcSscanf_s = tcase_create("s21_sscanf_s");
  tcase_add_test(TcSscanf_s, t_sscanf_s);
  suite_add_tcase(suite, TcSscanf_s);

  TCase* TcSscanf_u = tcase_create("s21_sscanf_u");
  tcase_add_test(TcSscanf_u, t_sscanf_u);
  suite_add_tcase(suite, TcSscanf_u);

  TCase* TcSscanf_x = tcase_create("s21_sscanf_x");
  tcase_add_test(TcSscanf_x, t_sscanf_x);
  suite_add_tcase(suite, TcSscanf_x);

  TCase* TcSscanf_p = tcase_create("s21_sscanf_p");
  tcase_add_test(TcSscanf_p, t_sscanf_p);
  suite_add_tcase(suite, TcSscanf_p);

  TCase* TcSscanf_n = tcase_create("s21_sscanf_n");
  tcase_add_test(TcSscanf_n, t_sscanf_n);
  suite_add_tcase(suite, TcSscanf_n);

  TCase* TcSprintf_char = tcase_create("s21_sprintf_char");
  tcase_add_test(TcSprintf_char, sprintf_char);
  suite_add_tcase(suite, TcSprintf_char);

  TCase* TcSprintf_int = tcase_create("s21_sprintf_int");
  tcase_add_test(TcSprintf_int, sprintf_int);
  suite_add_tcase(suite, TcSprintf_int);

  TCase* TcSprintf_un_int = tcase_create("s21_sprintf_unsigned_int");
  tcase_add_test(TcSprintf_un_int, sprintf_unsigned_int);
  suite_add_tcase(suite, TcSprintf_un_int);

  TCase* TcSprintf_f1 = tcase_create("s21_sprintf_float1");
  tcase_add_test(TcSprintf_f1, sprintf_1_f);
  suite_add_tcase(suite, TcSprintf_f1);

  TCase* TcSprintf_f2 = tcase_create("s21_sprintf_float2");
  tcase_add_test(TcSprintf_f2, sprintf_2_f);
  suite_add_tcase(suite, TcSprintf_f2);

  TCase* TcSprintf_f3 = tcase_create("s21_sprintf_float3");
  tcase_add_test(TcSprintf_f3, sprintf_3_f);
  suite_add_tcase(suite, TcSprintf_f3);

  TCase* TcSprintf_f4 = tcase_create("s21_sprintf_float4");
  tcase_add_test(TcSprintf_f4, sprintf_4_f);
  suite_add_tcase(suite, TcSprintf_f4);

  TCase* TcSprintf_f5 = tcase_create("s21_sprintf_float5");
  tcase_add_test(TcSprintf_f5, sprintf_5_f);
  suite_add_tcase(suite, TcSprintf_f5);

  TCase* TcSprintf_f6 = tcase_create("s21_sprintf_float6");
  tcase_add_test(TcSprintf_f6, sprintf_6_f);
  suite_add_tcase(suite, TcSprintf_f6);

  TCase* TcSprintf_f7 = tcase_create("s21_sprintf_float7");
  tcase_add_test(TcSprintf_f7, sprintf_7_f);
  suite_add_tcase(suite, TcSprintf_f7);

  TCase* TcSprintf_f8 = tcase_create("s21_sprintf_float8");
  tcase_add_test(TcSprintf_f8, sprintf_8_f);
  suite_add_tcase(suite, TcSprintf_f8);

  TCase* TcSprintf_f9 = tcase_create("s21_sprintf_float9");
  tcase_add_test(TcSprintf_f9, sprintf_9_f);
  suite_add_tcase(suite, TcSprintf_f9);

  TCase* TcSprintf_f10 = tcase_create("s21_sprintf_float10");
  tcase_add_test(TcSprintf_f10, sprintf_10_f);
  suite_add_tcase(suite, TcSprintf_f10);

  TCase* TcSprintf_f11 = tcase_create("s21_sprintf_float11");
  tcase_add_test(TcSprintf_f11, sprintf_11_f);
  suite_add_tcase(suite, TcSprintf_f11);

  TCase* TcSprintf_f12 = tcase_create("s21_sprintf_float12");
  tcase_add_test(TcSprintf_f12, sprintf_12_f);
  suite_add_tcase(suite, TcSprintf_f12);

  TCase* TcSprintf_f13 = tcase_create("s21_sprintf_float13");
  tcase_add_test(TcSprintf_f13, sprintf_13_f);
  suite_add_tcase(suite, TcSprintf_f13);

  TCase* TcSprintf_string_1 = tcase_create("s21_string_1");
  tcase_add_test(TcSprintf_string_1, sprintf_1_string);
  suite_add_tcase(suite, TcSprintf_string_1);

  TCase* TcSprintf_string_2 = tcase_create("s21_string_2");
  tcase_add_test(TcSprintf_string_2, sprintf_2_string);
  suite_add_tcase(suite, TcSprintf_string_2);

  TCase* TcSprintf_string_3 = tcase_create("s21_string_3");
  tcase_add_test(TcSprintf_string_3, sprintf_3_string);
  suite_add_tcase(suite, TcSprintf_string_3);

  TCase* TcSprintf_string_5 = tcase_create("s21_string_5");
  tcase_add_test(TcSprintf_string_5, sprintf_5_string);
  suite_add_tcase(suite, TcSprintf_string_5);

  TCase* TcSprintf_string_6 = tcase_create("s21_string_6");
  tcase_add_test(TcSprintf_string_6, sprintf_6_string);
  suite_add_tcase(suite, TcSprintf_string_6);

  TCase* TcSprintf_string_7 = tcase_create("s21_string_7");
  tcase_add_test(TcSprintf_string_7, sprintf_7_string);
  suite_add_tcase(suite, TcSprintf_string_7);

  TCase* TcSprintf_string_8 = tcase_create("s21_string_8");
  tcase_add_test(TcSprintf_string_8, sprintf_8_string);
  suite_add_tcase(suite, TcSprintf_string_8);

  TCase* TcSprintf_string_9 = tcase_create("s21_string_9");
  tcase_add_test(TcSprintf_string_9, sprintf_9_string);
  suite_add_tcase(suite, TcSprintf_string_1);

  TCase* TcSprintf_string_11 = tcase_create("s21_string_11");
  tcase_add_test(TcSprintf_string_11, sprintf_11_string);
  suite_add_tcase(suite, TcSprintf_string_11);

  TCase* TcSprintf_string_12 = tcase_create("s21_string_12");
  tcase_add_test(TcSprintf_string_12, sprintf_12_string);
  suite_add_tcase(suite, TcSprintf_string_12);

  TCase* TcSprintf_string_13 = tcase_create("s21_string_13");
  tcase_add_test(TcSprintf_string_13, sprintf_13_string);
  suite_add_tcase(suite, TcSprintf_string_13);
  return suite;
  return suite;
}

int main() {
  Suite* suite = example_suite_create();

  SRunner* runner = srunner_create(suite);
  srunner_run_all(runner, CK_NORMAL);

  int fail = srunner_ntests_failed(runner);
  srunner_free(runner);

  return fail ? EXIT_FAILURE : EXIT_SUCCESS;
}